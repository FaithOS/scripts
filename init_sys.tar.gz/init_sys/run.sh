#!/bin/bash
#author: kuilong.liu
#version: 1.0
#date: 2016-07-11
#desc: init sys scripts 

##var
basedir=$(cd `dirname $0`;pwd)

#check os 
OS=`cat /etc/issue|head -n1|awk '{print $1}'|tr '[A-Z]' '[a-z]'`
echo $OS
source $basedir/scripts/init_$OS.sh
