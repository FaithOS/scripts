#!/bin/bash
#author: kuilong.liu
#version: 1.0
#date: 2016-07-11
#os: ubuntu 14.04
#desc: init sys scripts 

##var
basedir=$(cd `dirname $0`;pwd)
echo $basedir
user=secneo
fun_arr=(add_user add_auth_key change_ssh_auth change_apt_source)

if [ `id -u` -ne 0 ];then
    echo "This scripts must run with root !!!"
    exit 1
fi
error () {
    echo "Error: Please check your choose"
}


add_user () {
    echo "##################添加用户$user######################"
    egrep "^sudo" /etc/group >& /dev/null
    if [ $? -ne 0 ];then
        groupadd sudo
    fi
    id $user 1>/dev/null 2>&1
    if [ $? -eq 0 ];then
        echo "$user already exists"
    else
        useradd -m $user -s /bin/bash
        usermod -G sudo $user
        id $user
    fi
}

add_auth_key () {
    echo "##################添加认证用户######################"
    id $user 1>/dev/null 2>&1
    if [ $? -ne 0 ];then
        echo "please add a user $user first !"
    elif [ ! -d "/home/$user/.ssh" ];then
        mkdir /home/$user/.ssh
        cp $basedir/conf/ubuntu/authorized_keys /home/$user/.ssh
        chown -R $user.$user /home/$user/.ssh
	cat /home/$user/.ssh/authorized_keys
    else
	echo "authorized_keys file already exists"
    fi   
    echo "##################设置免密码sudo######################"
    echo "%sudo  ALL=(ALL:ALL) NOPASSWD:ALL" >> /etc/sudoers
   
}

change_ssh_auth () {
    echo "##################更改ssh登录方式######################"
    PA=`egrep -v "^$|^#" /etc/ssh/sshd_config|grep PasswordAuthentication|awk '{print $2}'`
    if [ "$PA" == "no" ];then
        echo "password authentication already forbidden"
    elif [ "$PA" == "yes" ];then
    	mv /etc/ssh/sshd_config{,.bak}
    	cp $basedir/conf/ubuntu/sshd_config /etc/ssh/sshd_config
    	service ssh restart
    fi
}

change_apt_source () {
    echo "##################修改apt-get源######################"
    SOURCE=`egrep -v "^$|^#" /etc/apt/sources.list|head -n1|awk -F'/' '{print $3}'`
    if [ "$SOURCE" == "mirrors.aliyun.com" ];then
    	echo "apt-get sources is already update ,current is : mirrors.aliyun.com"
    else
    	mv /etc/apt/sources.list{,.bak}
    	cp $basedir/conf/ubuntu/sources.list /etc/apt/sources.list
    	apt-get update
    fi

}

init_iptables () {
    echo "##################添加防火墙策略######################"
    if [ -s /etc/iptables.up.rules ];then
        echo "iptables rule already set"
    else
        source $basedir/scripts/init_iptables.sh
        iptables-save > /etc/iptables.up.rules
        echo "pre-up iptables-restore < /etc/iptables.up.rules " >> /etc/network/interfaces
        echo "post-down iptables-save > /etc/iptables.up.rules" >> /etc/network/interfaces
    fi
}

export PS3="Please make a selection => "
echo "################ This is sys init script with Ubuntu 14.04 ################"
select var in all ${fun_arr[@]} init_iptables exit
    do 
        case $var in 
	    all)
			for i in ${fun_arr[@]}
			    do
				$i
			    done
			;;
				
	    add_user)
			add_user
			;;
	    add_auth_key)
			add_auth_key
			;;
	    change_ssh_auth)
			change_ssh_auth
			;;
	    change_apt_source)
			change_apt_source
			;;
	    init_iptables)
			init_iptables
			;;
	    exit)
			exit 0
			;;
	    *)
			error
	esac
    done

