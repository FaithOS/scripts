#!/bin/bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games

echo "+++++ display iptables rules +++++"
iptables -L -n
echo "+++++ set iptables default rules +++++"
iptables -P INPUT ACCEPT
iptables -P OUTPUT ACCEPT
iptables -P FORWARD ACCEPT
echo "+++++ clean iptables rules +++++"
iptables -F
iptables -X
echo "+++++ init iptables rules +++++"
iptables -A INPUT -s 111.207.253.210/32 -j ACCEPT
iptables -A INPUT -s 42.62.59.208/28 -j ACCEPT
iptables -A INPUT -s 42.62.15.1/29 -j ACCEPT
iptables -A INPUT -s 192.168.0.0/24 -j ACCEPT
iptables -A INPUT -p udp -m udp --dport 53 -j ACCEPT
iptables -A INPUT -p tcp -m tcp --dport 53 -j ACCEPT
iptables -A INPUT -m state --state RELATED,ESTABLISHED -j ACCEPT
iptables -A INPUT -p icmp -j ACCEPT
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -p tcp -m state --state NEW -m tcp --dport 22 -j ACCEPT
iptables -A INPUT -j REJECT --reject-with icmp-host-prohibited
iptables -A FORWARD -j REJECT --reject-with icmp-host-prohibited
echo "+++++ display iptables rules +++++"
iptables -L -n
echo "+++++ compeleted +++++"
